import React from "react";
import { NavigationContainer } from "@react-navigation/native";

import RootNav from "./src/navigation/RootNav";

export const AuthContext = React.createContext();

const App = () => {
  const [isLoggedIn, setIsLoggedIn] = React.useState(false);
  const authFuncs = {
    signIn: () => setIsLoggedIn(true),
    signOut: () => setIsLoggedIn(false)
  };
  return (
    <AuthContext.Provider value={authFuncs}>
      <NavigationContainer>
        <RootNav isLoggedIn={isLoggedIn} />
      </NavigationContainer>
    </AuthContext.Provider>
  );
};

export default App;
