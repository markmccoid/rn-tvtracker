import React from "react";
import { View, Text, StyleSheet } from "react-native";

const CreateAccount = () => (
  <View>
    <Text>CreateAccount Please</Text>
  </View>
);

export default CreateAccount;
