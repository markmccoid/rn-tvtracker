import React from "react";
import { View, Text, Button, StyleSheet } from "react-native";

const SignIn = ({ navigation }) => (
  <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
    <Text>SignIn Please</Text>
    <Button title="Sign In" onPress={() => alert("Sign in")} />
    <Button
      title="Create Account"
      onPress={() => navigation.push("CreateAccount")}
    />
  </View>
);

export default SignIn;
