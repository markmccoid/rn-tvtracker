import React from "react";
import { View, Text, Button, StyleSheet } from "react-native";
import { AuthContext } from "../../App";

export const Home = ({ navigation }) => {
  let { signOut } = React.useContext(AuthContext);
  return (
    <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
      <Text>Home Page</Text>
      <Button
        title="Details"
        onPress={() => navigation.push("Details", { name: "My Details" })}
      />
      <Button
        title="Other Details"
        onPress={() => navigation.push("Details")}
      />
      <Button title="Sign Out" onPress={signOut} />
    </View>
  );
};

export const Profile = ({ navigation }) => (
  <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
    <Text>Profile Page</Text>
    <Button
      title="Home"
      onPress={() => navigation.navigate("HomeStack", { screen: "Details" })}
    />
  </View>
);

export const Details = ({ route }) => (
  <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
    <Text>Details Page</Text>
    <Text>{route.params && route.params.name}</Text>
  </View>
);

export const SignIn = ({ navigation }) => {
  let { signIn } = React.useContext(AuthContext);
  return (
    <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
      <Text>SignIn Please</Text>
      <Button title="Sign In" onPress={signIn} />
      <Button
        title="Create Account"
        onPress={() => navigation.push("CreateAccount")}
      />
    </View>
  );
};

export const CreateAccount = () => (
  <View>
    <Text>CreateAccount Please</Text>
  </View>
);

export const Settings = ({ navigation }) => (
  <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
    <Text>Settings Page</Text>
    <Button
      title="Home"
      onPress={() => navigation.navigate("HomeStack", { screen: "Details" })}
    />
  </View>
);
