import React from "react";
import { createStackNavigator } from "@react-navigation/stack";

import { SignIn, CreateAccount } from "../screens/OtherScreens";

const AuthStack = createStackNavigator();

const AuthNav = () => {
  return (
    <AuthStack.Navigator>
      <AuthStack.Screen name="SignIn" component={SignIn} />
      <AuthStack.Screen
        name="CreateAccount"
        component={CreateAccount}
        options={{ title: "Create Account", animationEnabled: false }}
      />
    </AuthStack.Navigator>
  );
};

export default AuthNav;
