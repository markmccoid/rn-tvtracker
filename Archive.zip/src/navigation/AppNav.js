import React from "react";
import { Button } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { createDrawerNavigator } from "@react-navigation/drawer";

import { Profile, Home, Details, Settings } from "../screens/OtherScreens";

const Drawer = createDrawerNavigator();

//-- Main application Bottom Tabs ----------
const AppTabs = createBottomTabNavigator();
const AppTabsScreen = () => {
  return (
    <AppTabs.Navigator>
      <AppTabs.Screen name="HomeStack" component={HomeStackScreen} />
      <AppTabs.Screen name="Profile" component={Profile} />
    </AppTabs.Navigator>
  );
};

//-- Bottom Tabs Home Button Screens ---------
const HomeStack = createStackNavigator();
const HomeStackScreen = () => {
  return (
    <HomeStack.Navigator>
      <HomeStack.Screen
        name="Home"
        component={Home}
        options={{
          headerRight: () => (
            <Button
              onPress={() => alert("This is a button!")}
              title="Info"
              color="black"
            />
          )
        }}
      />
      <HomeStack.Screen name="Details" component={Details} />
    </HomeStack.Navigator>
  );
};

const AppNav = () => {
  return (
    //-- Define the Drawer screens.  HomeStack is part of bottom tabs, but settings is not.
    <Drawer.Navigator>
      <Drawer.Screen name="HomeStack" component={AppTabsScreen} />
      <Drawer.Screen name="Settings" component={Settings} />
    </Drawer.Navigator>
  );
};

export default AppNav;
