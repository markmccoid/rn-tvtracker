import React from "react";
import { createStackNavigator } from "@react-navigation/stack";

import AuthNav from "./AuthNav";
import AppNav from "./AppNav";
import { AuthContext } from "../../App";

const RootStack = createStackNavigator();

const RootNav = ({ isLoggedIn }) => {
  return (
    <RootStack.Navigator headerMode="none">
      {!isLoggedIn ? (
        <RootStack.Screen
          name="AuthNav"
          component={AuthNav}
          options={{
            animationEnabled: false
          }}
        />
      ) : (
        <RootStack.Screen
          name="AppNave"
          component={AppNav}
          options={{
            animationEnabled: false
          }}
        />
      )}
    </RootStack.Navigator>
  );
};

export default RootNav;
